// import 'package:get/get.dart';
// import 'package:hallo_doctor_client/app/modules/detail_order/controllers/detail_order_controller.dart';
// import 'package:hallo_doctor_client/app/modules/midtrans_payment/controller/midtrans_payment_controller.dart';
// import 'package:hallo_doctor_client/app/service/order_service.dart';
// import 'package:hallo_doctor_client/app/service/payment_service.dart';
// import 'package:hallo_doctor_client/app/service/user_service.dart';

// class MidtransPaymentBinding implements Bindings {
//   @override
//   void dependencies() {
//     Get.lazyPut<MidtransPaymentController>(() => MidtransPaymentController());
//     // Get.lazyPut<OrderService>(() => OrderService());
//     // Get.lazyPut<DetailOrderController>(() => DetailOrderController());
//     // Get.lazyPut<UserService>(() => UserService());
//     // Get.lazyPut<PaymentService>(
//     //   () => PaymentService(),
//     // );
//     // Get.lazyPut<OrderService>(() => OrderService());
//   }
// }
