import 'package:get/get.dart';

class ResetPasswordController extends GetxController {
  //TODO: Implement ResetPasswordController

  final count = 0.obs;

  @override
  void onClose() {}
  void increment() => count.value++;
}
