import 'package:get/get.dart';

class ListChatController extends GetxController {
  //TODO: Implement ListChatController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;
}
