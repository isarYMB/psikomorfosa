// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'image_carousel_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ImageCarousel _$ImageCarouselFromJson(Map<String, dynamic> json) =>
    ImageCarousel(
      imageUrl: json['imageUrl'] as String?,
      fileName: json['fileName'] as String?,
    );

Map<String, dynamic> _$ImageCarouselToJson(ImageCarousel instance) =>
    <String, dynamic>{
      'imageUrl': instance.imageUrl,
      'fileName': instance.fileName,
    };
