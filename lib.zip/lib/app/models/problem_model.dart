class ProblemModel {
  ProblemModel({this.problem, this.timeslotId});
  String? problem;
  String? timeslotId;
}
