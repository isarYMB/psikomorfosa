const currencySign = '\$';
